# Automated k6 load testing with Jenkins
This is an example repo for how to setup k6 with Jenkins to add load testing into an automation flow.

The full guide describing how to use this repository is located at:
https://blog.loadimpact.com/integrating-load-testing-with-jenkins

